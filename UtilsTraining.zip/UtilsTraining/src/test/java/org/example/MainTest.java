package org.example;


public class MainTest {

    public MainTest(String testName) {

    }
}


