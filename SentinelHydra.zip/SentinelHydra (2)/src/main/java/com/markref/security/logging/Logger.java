package com.markref.security.logging;

public interface Logger {

    void log(String massage);
}