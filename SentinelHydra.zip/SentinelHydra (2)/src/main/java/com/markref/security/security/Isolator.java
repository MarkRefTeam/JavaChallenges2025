package com.markref.security.security;

public class Isolator {

    public void isolate(String infectedPart) {
        System.out.println("Isolating: " + infectedPart);
    }
}