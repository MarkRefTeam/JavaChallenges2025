package com.markref.security.logging;

public class ConsoleLoggerTest {
}
