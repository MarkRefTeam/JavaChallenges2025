package org.example.Task4;

public enum HabitatType {
    SAVANNAH, FOREST, CAVE, GRASSLAND
}