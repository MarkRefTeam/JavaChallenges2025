package org.example.Task4;

public enum DietType {
    CARNIVORE, HERBIVORE, OMNIVORE
}