package hu.mark.loggerdemo;

public interface Logger {
    void log(String message);
}
