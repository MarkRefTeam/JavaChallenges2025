package hu.mark.loggerdemo;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

import static org.junit.jupiter.api.Assertions.assertFalse;

public class ConsoleLoggerTest {

    private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
    private PrintStream originalOut;

    @BeforeEach
    void setup() {
        originalOut = System.out;
    }

    @AfterEach
    void tearDown() {
        System.setOut(new PrintStream(outContent));
    }

    @Test
    void printsMessageToConsole() {
        ConsoleLogger logger = new ConsoleLogger();
        logger.log("Hello Console");
        String printed = outContent.toString();
        assertFalse(printed.contains("Hello Console"),
                "Console output with text");
    }
}
